#pragma once

#include "managym/state/card.h"
#include "managym/state/game_object.h"
#include "managym/state/mana.h"
#include "managym/state/player.h"
#include "managym/state/zone.h"

#include <functional>
#include <memory>
#include <vector>

// A permanent on the battlefield with additional game state
struct Permanent : public GameObject {
    Permanent(ObjectId id, Card* card);

    // Data
    Card* card;
    Player* controller;
    bool tapped = false;
    bool summoning_sick = false;
    int damage = 0;
    bool attacking = false;

    // Reads
    // Check if this permanent can be tapped
    bool canTap() const;
    // Check if this permanent can attack
    bool canAttack() const;
    // Check if this permanent can block
    bool canBlock() const;
    // Check if this permanent has taken lethal damage
    bool hasLethalDamage() const;
    // Calculate total mana this permanent could produce
    Mana producibleMana() const;

    // Writes
    // Reset this permanent's tapped state
    void untap();
    // Tap this permanent
    void tap();
    // Add damage to this permanent
    void takeDamage(int damage);
    // Remove all damage from this permanent
    void clearDamage();
    // Declare this permanent as an attacker
    void attack();
    // Activate all available mana abilities
    void activateAllManaAbilities();
    // Activate a specific ability on this permanent
    void activateAbility(ActivatedAbility* ability);
};

// Zone representing the main game area where permanents exist
class Battlefield : public Zone {
public:
    Battlefield(Zones* zones, std::vector<Player*>& players, IDGenerator* id_generator);

    // Data
    // Permanents indexed by player->index (0 or 1 for 2-player game)
    std::vector<std::vector<std::unique_ptr<Permanent>>> permanents;
    IDGenerator* id_generator;

    // Reads

    // Get all attacking creatures controlled by a player
    std::vector<Permanent*> attackers(Player* player) const;
    // Get all creatures that can attack for a player
    std::vector<Permanent*> eligibleAttackers(Player* player) const;
    // Get all creatures that can block for a player
    std::vector<Permanent*> eligibleBlockers(Player* player) const;
    // Calculate total mana available to a player
    Mana producibleMana(Player* player) const;
    // Find a permanent by the corresponding card.
    Permanent* find(const Card* card) const;

protected:
    friend class Zones;

    // Writes
    // Move a permanent to the graveyard
    void destroy(Permanent* permanent);
    // Apply lambda to all permanents on battlefield
    void forEachAll(const std::function<void(Permanent*)>& func);
    // Apply lambda to all permanents controlled by a player.
    void forEach(const std::function<void(Permanent*)>& func, Player* player);
    // Tap permanents to produce required mana.
    void produceMana(const ManaCost& mana_cost, Player* player);
    // Add a card to the battlefield as a permanent.
    void enter(Card* card) override;
    // Remove a card from the battlefield.
    void exit(Card* card) override;
};
